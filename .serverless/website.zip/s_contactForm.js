
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'songneilsong',
  applicationName: 'extraartinary',
  appUid: 'KTn6z24GkXtdhJx3mN',
  orgUid: 'F20s61qSpGCnhvblzh',
  deploymentUid: '9078336f-a9b3-4ad8-ba67-cc25a3517e72',
  serviceName: 'website',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.9',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'website-dev-contactForm', timeout: 6 };

try {
  const userHandler = require('./backend/contactForm.js');
  module.exports.handler = serverlessSDK.handler(userHandler.send, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}