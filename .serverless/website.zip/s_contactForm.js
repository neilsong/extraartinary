
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'songneilsong',
  applicationName: 'extraartinary',
  appUid: 'KTn6z24GkXtdhJx3mN',
  orgUid: 'F20s61qSpGCnhvblzh',
  deploymentUid: '26cf9c48-6919-4791-b7eb-0058b5c9e31a',
  serviceName: 'website',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.9',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'website-dev-contactForm', timeout: 6 };

try {
  const userHandler = require('./backend/contactForm.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}