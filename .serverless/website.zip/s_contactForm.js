
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'songneilsong',
  applicationName: 'extraartinary',
  appUid: 'KTn6z24GkXtdhJx3mN',
  orgUid: 'F20s61qSpGCnhvblzh',
  deploymentUid: 'cfbec3eb-0ccd-4033-a023-b2df59d89f24',
  serviceName: 'website',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.9',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'website-dev-contactForm', timeout: 6 };

try {
  const userHandler = require('./backend/contactForm.js');
  module.exports.handler = serverlessSDK.handler(userHandler.send, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}